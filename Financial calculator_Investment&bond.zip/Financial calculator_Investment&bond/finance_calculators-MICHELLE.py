import math
pr = 0
r = 0
time = 0

def investment():
    global pr
    global rate
    global time
    pr = float(input("Enter the principal amount you want to deposit: "))
    rate = float(input("Enter interest rate: "))
    time = float(input("Enter the number of years you plan to invest: \n"))
    simple_compound = str(input("Select either 'simple' or 'compound' interest. \n")).lower()
    if simple_compound == "simple":
        "simple" == simple_compound
        simple_compound = pr*(1 + r * time)
        total = simple_compound
        print(f"Interest earned over {time} years: {total:.2f}".format())
    
    elif simple_compound == "compound":
        simple_compound = pr*math.pow((1+r),time)
        total = simple_compound
        print(f"Interest earned over {time} years: {total:.2f}".format())
       
def bond():
    global pr
    global rate
    global time
    pri = float(input("Enter the current value of the house: \n"))
    intr = float(input("Enter interest rate: \n"))
    i = ((intr/100)/12)/12
    no = float(input("Enter the duration in months: \n"))
    monthly = float(math.floor((i*pri)/(1-(1+i)**(-no))))
    print(f"The monthly repayment: {monthly:.2f}".format())


def main():
    print("WELCOME TO SIMLPYTECH'S FINANCIAL CALCULATOR \n")

    while True:
      invest_bond= input("Choose either 'Investment' or 'Bond' from the menu below: \n \nInvestment    - to calculate the amount of interest you'll earn on interest \nBond          - to calculate the amount you'll have to pay on a home loan \n").lower()
      if invest_bond == "investment":
          investment()

      elif invest_bond == "bond":
          bond()
      else:
          print("Invalid option, Try again")

if __name__ == "__main__":
    main()
            